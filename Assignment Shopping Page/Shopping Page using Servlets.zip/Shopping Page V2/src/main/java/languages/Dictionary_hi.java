package languages;

import java.util.ListResourceBundle;

public class Dictionary_hi extends ListResourceBundle{
	Object obj[][]= {
			{"username","उपयोगकर्ता नाम"},
			{"password","कुंजिका"}
	};

	
	protected Object[][] getContents() {
		// TODO Auto-generated method stub
		return obj;
	}
}
