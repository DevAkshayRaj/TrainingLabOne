package languages;

import java.util.ListResourceBundle;

public class Dictionary_ta extends ListResourceBundle{
	Object obj[][]= {
			{"username","பயனர்பெயர்"},
			{"password","கடவுச்சொல்"}
	};

	
	protected Object[][] getContents() {
		// TODO Auto-generated method stub
		return obj;
	}
}
