package model;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import databaseutils.ItemDetails;

public class DeleteItemAction extends Action {
	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {

		try {
			HttpSession session=request.getSession();
			ArrayList<ItemDetails> data=(ArrayList<ItemDetails>)session.getAttribute("invoice");
			for(int i=0;i<data.size();i++) {
				if(request.getParameter(Integer.toString(i+1))!=null) {
					data.remove(i);
				}
			}
			session.setAttribute("invoice", data);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "shop3";
	}
}
