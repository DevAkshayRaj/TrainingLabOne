package control;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet(name = "MyServlet", urlPatterns = {"/Logout.do","/lang.do","/login.do","/shop.do","/generate.do","/Register.do","/LoginAgain.do"}, initParams={
@WebInitParam(name="config", value="/WEB-INF/config.properties"), 
@WebInitParam(name="dbconfig", value="/WEB-INF/db.properties")})

public class ActionServlet extends HttpServlet {
	RequestProcessor rp;
	Properties props;
	@Override
	public void init(ServletConfig config) throws ServletException {
		try {
			String configFile=config.getInitParameter("config");
			String DBconfigFile=config.getInitParameter("dbconfig");
			String configpath=config.getServletContext().getRealPath(configFile);
			String dbconfigpath=config.getServletContext().getRealPath(DBconfigFile);
			config.getServletContext().setAttribute("path", configpath);
			props=new Properties();
			props.load(new FileInputStream(dbconfigpath));
			Class.forName(props.getProperty("driver"));
			config.getServletContext().setAttribute("properties", props);
			this.rp=new RequestProcessor();
		}catch(Exception e) {
			e.printStackTrace();
		}
		super.init(config);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      System.out.println("Hello");
	      HttpSession session=request.getSession();
	      session.setMaxInactiveInterval(300);
	      this.rp.process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
