package model;

import java.util.ListResourceBundle;

public class Dictionary_en extends ListResourceBundle{
	Object obj[][]= {
			{"username","username"},
			{"password","password"}
	};

	
	protected Object[][] getContents() {
		// TODO Auto-generated method stub
		return obj;
	}
}
