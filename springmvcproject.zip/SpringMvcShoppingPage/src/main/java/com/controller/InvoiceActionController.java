package com.controller;

import java.util.ArrayList;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.service.InvoiceGenerator;
import com.service.RegisterService;
import com.utils.ExcelWriter.ExcelWriter;
import com.utils.email.SendEmail;
import com.utils.pdfutil.PdfWriterNew;
import com.utils.sms.SendSms;


@Controller
@RequestMapping("generate")
public class InvoiceActionController {
	
	@Autowired
	private InvoiceGenerator ig;
	@Autowired
	private RegisterService rs;
	
	public synchronized final InvoiceGenerator getIg() {
		return ig;
	}

	public synchronized final void setIg(InvoiceGenerator ig) {
		this.ig = ig;
	}

	@RequestMapping(value="/getinvoice",method=RequestMethod.POST)
	public ModelAndView getInvoice(HttpServletRequest request,ModelAndView mandv) {
		try {
			String sms=request.getParameter("sms");
			String email=request.getParameter("email");
			String pdf=request.getParameter("pdf");
			String excel=request.getParameter("excel");
			HttpSession session=request.getSession();
			int invno=Integer.parseInt((String)session.getAttribute("invno"));
			//Properties ps=(Properties)request.getServletContext().getAttribute("properties");
			
			ArrayList<ArrayList<String>> finalData=ig.getInvoice(invno);
			if(pdf!=null) {
				
				PdfWriterNew createpdf=new PdfWriterNew();
				createpdf.convert(finalData, "invoice"+Integer.toString(invno)+"PDF");
			}
			if(excel!=null) {
				ExcelWriter ew= new ExcelWriter();
				ew.convert(finalData,"invoice"+Integer.toString(invno)+"Excel");
			}
			if(email!=null) {
				int cid=(Integer)session.getAttribute("id");
				String customeremail=rs.getEmail(cid);
//				LoginServiceImpl ll=LoginServiceImpl.getObject(ps);
//				System.out.println("Now"+a);
//				System.out.println("Now "+ll.getEmail(a));
				SendEmail.send(finalData, "Akshay@1999",customeremail);
			}if(sms!=null) {
				int a=(Integer)session.getAttribute("id");
//				LoginServiceImpl ll=LoginServiceImpl.getObject(ps);
//				SendSms.SendMessage(ig.getInvoice(invno), ll.getPhone(a));
			}
			mandv.addObject("InvoiceData",ig.getInvoice(invno));
			mandv.setViewName("InvoiceTable");
		}catch(Exception e) {
			e.printStackTrace();
		}

		return mandv;
	}
}
