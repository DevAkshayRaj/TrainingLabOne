package com.initconfiguration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration.Dynamic;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

public class WebInitClass implements WebApplicationInitializer{
	@Override
	public void onStartup(ServletContext servletcontext) throws ServletException {
		AnnotationConfigWebApplicationContext webcfg=new AnnotationConfigWebApplicationContext();
		webcfg.setServletContext(servletcontext);
		webcfg.register(SpringInitClass.class);
		
		DispatcherServlet disp=new DispatcherServlet(webcfg);
		
		Dynamic dservlet=servletcontext.addServlet("dispatcher",disp);
		dservlet.addMapping("/");
		dservlet.setLoadOnStartup(1);

	}
}
