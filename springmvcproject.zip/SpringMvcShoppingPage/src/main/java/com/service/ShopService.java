package com.service;

import java.util.ArrayList;

import com.model.ItemDetailsMasterDto;
import com.model.ItemTransactionDetailsDto;


public interface ShopService {
	public ArrayList<ItemDetailsMasterDto> getDetails(int shopid);
	public int addIteminInvoice(ItemTransactionDetailsDto itm);
	public int getInvoiceNumber();
	public int addInvoiceMaster(int invno,int custno);
	public ItemDetailsMasterDto getItemDetails(int itemid);
}
