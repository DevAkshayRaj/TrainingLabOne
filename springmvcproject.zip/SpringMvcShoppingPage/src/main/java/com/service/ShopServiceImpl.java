package com.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.daomodel.InvoiceMasterDao;
import com.daomodel.ItemDetailsMasterDao;
import com.daomodel.ItemTransactionDetailsDao;
import com.model.InvoiceMasterDto;
import com.model.ItemDetailsMasterDto;
import com.model.ItemTransactionDetailsDto;

@Service
@Transactional
public class ShopServiceImpl implements ShopService{
	
	@Autowired
	private ItemDetailsMasterDao idm;
	@Autowired
	private InvoiceMasterDao imd;
	@Autowired
	private ItemTransactionDetailsDao itdo;
	@Override
	public ArrayList<ItemDetailsMasterDto> getDetails(int shopid) {
		List<ItemDetailsMasterDto> temp=idm.findItemByShopId(shopid);
		return new ArrayList<ItemDetailsMasterDto>(temp);
	}

	@Override
	public int addIteminInvoice(ItemTransactionDetailsDto itm) {
		try {
			itdo.insertItemTransactionDetails(itm);
			return 0;
		}catch(Exception e) {
			e.printStackTrace();
			return -1;
		}
	}

	@Override
	public int getInvoiceNumber() {
		return imd.getInvoicNumber()+1;
	}

	@Override
	public int addInvoiceMaster(int invno,int custno) {
		try {
			InvoiceMasterDto invm=InvoiceMasterDto.getClone();
			invm.setCustomerno(custno);
			invm.setInvDate(LocalDate.now());
			invm.setInvno(invno);
			imd.insertInvoiceDetails(invm);
			return 1;
		}catch(Exception e) {
			e.printStackTrace();
			return -1;
		}
	}

	@Override
	public ItemDetailsMasterDto getItemDetails(int itemid) {
		return idm.findItemById(itemid);
	}

}
