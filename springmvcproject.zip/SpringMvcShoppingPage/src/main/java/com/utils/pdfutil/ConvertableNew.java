package com.utils.pdfutil;

import java.util.ArrayList;

public interface ConvertableNew {
	public void convert(ArrayList<ArrayList<String>> data,String opfilename) throws Exception;

}
