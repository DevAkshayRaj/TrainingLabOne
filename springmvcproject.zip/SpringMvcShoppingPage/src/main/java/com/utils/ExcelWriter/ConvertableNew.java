package com.utils.ExcelWriter;

import java.util.ArrayList;

public interface ConvertableNew {
	public void convert(ArrayList<ArrayList<String>> data,String opfilename) throws Exception;

}
