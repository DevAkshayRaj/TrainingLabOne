package pdfutil;

import java.util.ArrayList;

public interface RmiConvertableNew {
	public void convert(ArrayList<ArrayList<String>> data,String opfilename) throws Exception;

}
